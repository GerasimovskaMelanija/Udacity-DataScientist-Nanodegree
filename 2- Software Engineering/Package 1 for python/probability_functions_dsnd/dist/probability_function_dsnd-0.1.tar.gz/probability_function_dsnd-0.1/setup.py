from setuptools import setup

setup(name='probability_function_dsnd',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['probability_function_dsnd'],
      author = 'Melanija Gerasimovska',
      author_email = 'melanija_gerasimovska@hotmail.com',
      zip_safe=False)
