from setuptools import setup

setup(name='tic_tac_toe_two_players',
      version='0.1',
      description='Game Tic Tac Toe for two players',
      packages=['tic_tac_toe_two_players'],
      author = 'Melanija Gerasimovska',
      author_email = 'melanija_gerasimovska@hotmail.com',
      zip_safe=False)
